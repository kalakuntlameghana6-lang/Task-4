import streamlit as st
import pandas as pd
import plotly.express as px

st.set_page_config(page_title="Sales & Financial Dashboard", page_icon="📊", layout="wide")
st.title("📊 Sales & Financial Performance Dashboard")
st.caption("Interactive business dashboard | Sample synthetic dataset for internship task")

@st.cache_data
def load_data():
    data = pd.read_csv("sales_financial_dataset.csv", parse_dates=["Order_Date"])
    return data

df = load_data()

st.sidebar.header("Dashboard Filters")
regions = st.sidebar.multiselect("Region", sorted(df["Region"].unique()), default=sorted(df["Region"].unique()))
categories = st.sidebar.multiselect("Category", sorted(df["Category"].unique()), default=sorted(df["Category"].unique()))
channels = st.sidebar.multiselect("Sales Channel", sorted(df["Sales_Channel"].unique()), default=sorted(df["Sales_Channel"].unique()))
min_date, max_date = df["Order_Date"].min().date(), df["Order_Date"].max().date()
date_range = st.sidebar.date_input("Order Date Range", value=(min_date, max_date), min_value=min_date, max_value=max_date)

filtered = df[df["Region"].isin(regions) & df["Category"].isin(categories) & df["Sales_Channel"].isin(channels)]
if isinstance(date_range, tuple) and len(date_range) == 2:
    filtered = filtered[filtered["Order_Date"].dt.date.between(date_range[0], date_range[1])]

if filtered.empty:
    st.warning("No records match the selected filters. Please adjust the filters.")
    st.stop()

total_sales = filtered["Sales"].sum()
total_profit = filtered["Profit"].sum()
total_orders = filtered["Order_ID"].nunique()
avg_margin = filtered["Profit"].sum() / total_sales * 100 if total_sales else 0

c1, c2, c3, c4 = st.columns(4)
c1.metric("Total Sales", f"₹{total_sales:,.0f}")
c2.metric("Total Profit", f"₹{total_profit:,.0f}")
c3.metric("Orders", f"{total_orders:,}")
c4.metric("Profit Margin", f"{avg_margin:.1f}%")

st.divider()
left, right = st.columns(2)
monthly = filtered.set_index("Order_Date").resample("MS")[["Sales", "Profit"]].sum().reset_index()
with left:
    st.subheader("Sales & Profit Trend")
    trend = monthly.melt(id_vars="Order_Date", value_vars=["Sales", "Profit"], var_name="Metric", value_name="Amount")
    fig = px.line(trend, x="Order_Date", y="Amount", color="Metric", markers=True, title="Monthly performance")
    st.plotly_chart(fig, use_container_width=True)
with right:
    st.subheader("Sales by Region")
    reg = filtered.groupby("Region", as_index=False)["Sales"].sum().sort_values("Sales", ascending=False)
    st.plotly_chart(px.bar(reg, x="Region", y="Sales", color="Region", title="Regional sales"), use_container_width=True)

left, right = st.columns(2)
with left:
    st.subheader("Profit by Category")
    cat = filtered.groupby("Category", as_index=False)["Profit"].sum()
    st.plotly_chart(px.pie(cat, names="Category", values="Profit", hole=0.45, title="Profit contribution"), use_container_width=True)
with right:
    st.subheader("Sales Channel Performance")
    ch = filtered.groupby("Sales_Channel", as_index=False)[["Sales", "Profit"]].sum()
    st.plotly_chart(px.bar(ch, x="Sales_Channel", y=["Sales", "Profit"], barmode="group", title="Sales and profit by channel"), use_container_width=True)

st.subheader("Detailed Transaction Data")
st.dataframe(filtered.sort_values("Order_Date", ascending=False), use_container_width=True, hide_index=True)
st.download_button("⬇️ Download filtered data (CSV)", filtered.to_csv(index=False).encode("utf-8"),
                   "filtered_sales_data.csv", "text/csv")
st.caption("Note: Dataset is synthetic and intended for learning/demo purposes, not real company reporting.")

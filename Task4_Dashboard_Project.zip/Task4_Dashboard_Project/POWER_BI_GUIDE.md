# Power BI setup guide

1. Open **Power BI Desktop**.
2. Select **Get Data → Text/CSV** and import `sales_financial_dataset.csv`.
3. Confirm `Order_Date` is set to the **Date** data type; select **Load**.
4. Create these measures from **Modeling → New measure**:

```DAX
Total Sales = SUM(Sales_Financial_Dataset[Sales])

Total Profit = SUM(Sales_Financial_Dataset[Profit])

Total Orders = DISTINCTCOUNT(Sales_Financial_Dataset[Order_ID])

Profit Margin % =
DIVIDE([Total Profit], [Total Sales], 0) * 100
```

5. Add four **Card** visuals for Total Sales, Total Profit, Total Orders and Profit Margin %.
6. Add a **Line chart**: `Order_Date` on X-axis; `Sales` and `Profit` on Y-axis.
7. Add a **Clustered column chart**: `Region` on X-axis and `Sales` on Y-axis.
8. Add a **Donut chart**: `Category` as Legend and `Profit` as Values.
9. Add a **Clustered bar/column chart**: `Sales_Channel` as Axis and `Sales`, `Profit` as Values.
10. Add slicers for `Region`, `Category`, `Sales_Channel` and `Order_Date`.
11. Use a consistent theme (navy, teal and light background), align visuals, and add a title.
12. Save as `Task4_Sales_Dashboard.pbix`.

## Recommended layout
- Top: dashboard title and four KPI cards.
- Middle: monthly sales/profit trend and sales by region.
- Bottom: profit by category and channel performance.
- Left or top panel: slicers/filters.

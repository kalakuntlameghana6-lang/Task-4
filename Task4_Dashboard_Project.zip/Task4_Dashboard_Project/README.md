# Task 4 – Dashboard Design

## Project
**Sales & Financial Performance Dashboard**  
Goal: help business stakeholders monitor sales, profit, order volume, profit margin and trends.

## Files
- `sales_financial_dataset.csv` – sample sales/financial dataset (600 rows).
- `app.py` – interactive dashboard built with Streamlit and Plotly.
- `requirements.txt` – Python dependencies.
- `Task4_Dashboard_Summary.pptx` – presentation summary.
- `POWER_BI_GUIDE.md` – steps to recreate the dashboard in Power BI.

## Run the interactive dashboard
1. Install Python 3.10+.
2. Open this folder in VS Code.
3. Open Terminal and run:
   ```bash
   pip install -r requirements.txt
   streamlit run app.py
   ```
4. Streamlit opens the dashboard in your browser.
5. Use the sidebar filters for Region, Category, Sales Channel and Date Range.

## Important note
The included dataset is synthetic sample data created for practice. Replace it with a permitted Kaggle sales/financial dataset if your internship evaluator requires an external Kaggle source. Keep the same column names or update the dashboard code.

## Dashboard KPIs
- Total Sales = SUM(Sales)
- Total Profit = SUM(Profit)
- Orders = DISTINCTCOUNT(Order_ID)
- Profit Margin = SUM(Profit) / SUM(Sales) × 100

## Suggested business insights to discuss
- Compare monthly sales and profit to identify growth or decline.
- Compare regional performance to identify strong and weak markets.
- Review profit contribution by category.
- Compare sales channels to understand where revenue and profit are generated.
